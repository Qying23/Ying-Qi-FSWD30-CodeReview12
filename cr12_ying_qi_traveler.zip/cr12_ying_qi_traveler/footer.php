<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_ying_qi_traveler
 */

?>

<div class="parallax" style="margin-top: 30px;"></div>
	<div id="contact" class="text-center">
	  <div class="container">
	    <div class="section-title center">
	      <h2>Contact</h2>
	      <hr>
	    </div>
	    <div class="col-md-8 col-md-offset-2">
	      <div class="col-md-4"> <i class="glyphicon glyphicon-home fa-2x"></i>
	        <p>Kettebrückengasse<br>
	          1040 Wien</p>
	      </div>
	      <div class="col-md-4"> <i class="glyphicon glyphicon-envelope fa-2x"></i>
	        <p>foodtravel@gmail.com</p>
	      </div>
	      <div class="col-md-4"> <i class="glyphicon glyphicon-earphone fa-2x"></i>
	        <p> +43 699 198 402 03</p>
	      </div>
	      <div class="clearfix"></div>
	    </div>
	    <div class="col-md-8 col-md-offset-2">
	      <h3>Mail Us</h3>
	      <form name="sentMessage" id="contactForm" novalidate>
	        <div class="row">
	          <div class="col-md-6">
	            <div class="form-group">
	              <input type="text" id="name" class="form-control" placeholder="Name" required="required">
	              <p class="help-block text-danger"></p>
	            </div>
	          </div>
	          <div class="col-md-6">
	            <div class="form-group">
	              <input type="email" id="email" class="form-control" placeholder="Email" required="required">
	              <p class="help-block text-danger"></p>
	            </div>
	          </div>
	        </div>
	        <div class="form-group">
	          <textarea name="message" id="message" class="form-control" rows="4" placeholder="write me" required></textarea>
	          <p class="help-block text-danger"></p>
	        </div>
	        <div id="success"></div>
	        <button type="submit" class="btn btn-default">submit</button>
	      </form>
	    </div>
	  </div>
	</div>

	<footer class="blog-footer text-center jumbotron">
   
	    <div class="container">
	    	<p class="left">&copy; 2018 All right reserved by Ying Qi</p> 
	        <ul id="right">
	            <li><a href="#" title="Facebook"><i class="fa fa-facebook fa-2x"></i></a></li>
	            <li><a href="#" title="Twitter"><i class="fa fa-twitter fa-2x"></i></a></li>
	            <li><a href="#" title="Linkedin"><i class="fa fa-linkedin fa-2x"></i></a></li>
	            <li><a href="#" title="Pinterest"><i class="fa fa-pinterest fa-2x"></i></a></li>
	            <li><a href="#" title="Google plus"><i class="fa fa-google-plus fa-2x"></i></a></li>
	            <li><a href="#" title="Github"><i class="fa fa-github fa-2x"></i></a></li>
	        </ul>
	    </div>
        
   </footer>
   <?php wp_footer(); ?>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
